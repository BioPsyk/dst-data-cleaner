##########################
##########################
#### LifeLines1986_2021
##########################
##########################

rm(list = ls())
library(dplyr)

##########################
#### Input data
bef_bop <- haven::read_sas("E:/rawdata/708614/grunddata/befbop202112.sas7bdat")
colnames(bef_bop) <- tolower(colnames(bef_bop))
bef_adr <- haven::read_sas("E:/rawdata/708614/grunddata/befadr202203.sas7bdat")
colnames(bef_adr) <- tolower(colnames(bef_adr))
load(file = "E:/workdata/708614/Datasets/population1986_2021.RData")
municipalities <- readxl::read_excel("E:/workdata/708614/Datasets/municipalities.xlsx")
##########################

##########################
#### Output data
folder_output <- "E:/workdata/708614/Datasets/"
##########################

start_year <- 1986
end_year <- 2021

# The dataset 'population' contains all individuals born in Denmark (one observation per person)
# We merge the population dataset with the register of residences (within Denmark)
# where they have lived since 1986 and onward

# First we keep only residences in Denmark (excluding Greenland)
municipalities_DK <- unique(c(municipalities$OldCommunityCode, municipalities$NewCommunityCode))

bef_adr <- bef_adr %>%
  filter(kom %in% municipalities_DK) 

bef_bop <- bef_bop %>%
  filter(adresse_id %in% unique(bef_adr$adresse_id))


# In dataset migrations, every person can have more than one observation (one per different residence in Denmark)
migrations <- population %>% inner_join(bef_bop, by = "pnr") %>%
  select(pnr, birth_d, death_d, bop_vfra, bop_vtil, birth_country)
rm(population, bef_bop)

# We create an indicator to group consecutive periods of different residences.
# We consider two periods to be consecutive if they are separated by 60 days or less
# In other words, if someone is not registered in any Danish residence for more than 60 days,
# we consider this person to be living abroad during this period
migrations <- migrations %>%
  group_by(pnr) %>%
  arrange(pnr, bop_vfra) %>%
  mutate(
    days = as.numeric(bop_vfra - lag(bop_vtil)),
    new = ((pnr == lag(pnr)) & (days > 60)),
    new = ifelse(row_number() == 1, 1, new)
  )

migrations <- migrations %>%
  group_by(pnr) %>%
  arrange(pnr, bop_vfra) %>%
  mutate(
    obs_nr = cumsum(new),
  )
  
migrations <- migrations %>%
  group_by(pnr, birth_country, birth_d, death_d, obs_nr) %>%
  summarise(
    entry_d = min(bop_vfra),
    exit_d = max(bop_vtil)
  ) %>%
  ungroup() %>%
  select(pnr, birth_country, birth_d, death_d, lifeline_nr = obs_nr, entry_d, exit_d)

# Check residences before dying
check <-  migrations %>%
  filter(!is.na(death_d)) %>%
  group_by(pnr) %>%
  arrange(lifeline_nr) %>%
  slice_tail(n = 1) %>%
  ungroup()
   
nrow(check %>%
       filter(exit_d == death_d)) 
nrow(check %>%
       filter(exit_d == death_d-1)) 
# Most individuals have residence until the day before dying
rm(check)

migrations <- migrations %>%
  group_by(pnr) %>%
  mutate(max_nr = max(lifeline_nr)) %>%
  ungroup() %>%
  mutate(
    exit_d = as.Date(ifelse(max_nr == lifeline_nr & !is.na(death_d) & exit_d == death_d - 1, death_d, exit_d), origin = "1970-01-01")
  ) %>%
  select(-max_nr)

# We exclude periods finishing before 1986 or those dying before 1986
migrations <- migrations %>%
  filter(
    exit_d >= as.Date(paste0(start_year, "-01-01")),
    is.na(death_d) | (!is.na(death_d) & death_d >= as.Date(paste0(start_year, "-01-01"))),
    is.na(death_d) | (!is.na(death_d) & death_d >= entry_d)
  )

# We follow individuals since birth, immigration or 1st Jan 1986, whatever happens last
migrations <- migrations %>%
  mutate(
    x = pmax(birth_d, entry_d, as.Date(paste0(start_year, "-01-01"))),
    entry = case_when(
      x == birth_d ~ 1,
      x != birth_d & x != as.Date(paste0(start_year, "-01-01")) ~ 2,
      x != birth_d & x == as.Date(paste0(start_year, "-01-01")) ~ 0
    )
  ) %>%
  mutate(entry_d = x) %>%
  select(-x)
table(migrations$entry, useNA = "always")

# We follow individuals until death, emigration, or 31st Dec 2021
migrations <- migrations %>%
  mutate(
    death_d = as.Date(ifelse(is.na(death_d), as.Date("9999-12-29"), death_d), origin = "1970-01-01"),
    #exit_d = as.Date(ifelse(exit_d == death_d - 1, death_d, exit_d), origin = "1970-01-01"), 
    x = pmin(death_d, exit_d, as.Date(paste0(end_year, "-12-31"), origin = "1970-01-01")),
    exit = case_when(
      death_d == x ~ 1,
      x != death_d & x == exit_d ~ 2,
      x != death_d & x != exit_d ~ 0
    )
  ) %>%
  mutate(exit_d = x) %>%
  select(-x)
table(migrations$exit, useNA = "always")

nrow(migrations %>% filter(birth_d > entry_d))
nrow(migrations %>% filter(entry_d > exit_d))
nrow(migrations %>% filter(death_d < exit_d))
  
# We create an indicator (regnr) specifying the different periods of someone living in Denmark
migrations <- migrations %>%
  group_by(pnr) %>%
  arrange(entry_d) %>%
  mutate(regnr= row_number()) %>%
  ungroup() %>%
  select(pnr, regnr, entry_d, entry, exit_d, exit) %>%
  arrange(pnr, regnr)

nrow(migrations)
length(unique(migrations$pnr))

save(migrations, file=paste0(folder_output, "LifeLines1986_2021.RData"))
haven::write_dta(migrations, path=paste0(folder_output, "Stata/LifeLines1986_2021.dta"))
