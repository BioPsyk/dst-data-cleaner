##########################
##########################
#### ses1985_2021
##########################
##########################

rm(list = ls())
library(dplyr)
source("E:/workdata/708614/FAQA/Data management/FORMAT_audd_level.R")

##########################
#### Input data
folder_input <- "E:/rawdata/708614/grunddata/"
load("E:/workdata/708614/Datasets/population1986_2021.RData")
load("E:/workdata/708614/Datasets/LifeLines1986_2021.RData")
uddf <- haven::read_sas("E:/rawdata/708614/grunddata/uddf202009.sas7bdat") %>%
  distinct()
colnames(uddf) <- tolower(colnames(uddf))
##########################


##########################
#### Output data
folder_output <- "E:/workdata/708614/Datasets/"
##########################

inflation <- data.frame(
  year = 1985:2022,
  inflation2015 = c(50.9, 52.8, 54.9, 57.4, 60.1, 61.7, 63.2, 64.5, 65.3, 66.6, 68.0, 69.5, 71.0, 72.3, 74.1, 76.2, 78.0, 79.9,
                81.6, 82.5, 84.0, 85.6, 87.1, 90.1, 91.2, 93.3, 95.9, 98.2, 99.0, 99.6, 100, 100.3,
                101.4, 102.2, 103.0, 103.4, 105.4, 113.5)
)

ses <- data.frame()

for(year in 1985:2021) {
  print(year)
  bef_year <- haven::read_sas(paste0(folder_input, "bef", year, "12.sas7bdat"))
  colnames(bef_year) <- tolower(colnames(bef_year))
  
  ses_year <- bef_year %>%
    select(pnr, familie_id, sex = koen, birth_d = foed_dag, civst, family_type = familie_type) %>%
    distinct()
  rm(bef_year)
  
  ## Number of days registered
  migrations_year <- migrations %>%
    filter(
      entry_d <= as.Date(paste0(year, "-12-31")),
      exit_d >= as.Date(paste0(year, "-01-01"))
    ) %>%
    mutate(
      entry_d = pmax(entry_d, as.Date(paste0(year, "-01-01"))),
      exit_d = pmin(exit_d, as.Date(paste0(year, "-12-31")))
    ) %>%
    mutate(bef_days = as.numeric(exit_d - entry_d + 1)) %>%
    group_by(pnr) %>%
    summarise(bef_days = sum(bef_days)) %>%
    ungroup()
  
  ses_year <- ses_year %>%
    left_join(migrations_year) %>%
    mutate(bef_days = ifelse(is.na(bef_days), 0, bef_days))
  rm(migrations_year)
  
  ## Education
  if(year >= 2008) {
    month <- "09"
  } else {
    month <- "12"
  }
  udda <- haven::read_sas(paste0(folder_input, "udda", year, month, ".sas7bdat")) %>%
    distinct()
  colnames(udda) <- tolower(colnames(udda))
  
  ses_year <- ses_year %>%
    left_join(udda %>% select(pnr, edu_udda = hfaudd) %>% distinct(), by = "pnr")
  rm(udda)
  
  ## Education (from UDDF)
  uddf_year <- uddf %>%
    filter(hf_vfra <= as.Date(paste0(year, "-12-31"))) %>%
    group_by(pnr) %>%
    arrange(hf_vfra) %>%
    slice_tail(n = 1) %>%
    ungroup()
  
  ses_year <- ses_year %>%
    left_join(uddf_year %>% select(pnr, edu_uddf = hfaudd) %>% distinct(), by = "pnr")
  rm(uddf_year)
  
  # We prioritize UDDF over UDDA except in year 2021 (UDDF updated until 2020)
  if(year == 2021) {
    ses_year <- ses_year %>%
      mutate(
        edu = ifelse(!is.na(edu_udda), edu_udda, edu_uddf)
      ) %>%
      select(-edu_uddf, -edu_udda)
  } else {
    ses_year <- ses_year %>%
      mutate(
        edu = ifelse(!is.na(edu_uddf), edu_uddf, edu_udda)
      ) %>%
      select(-edu_uddf, -edu_udda)
  }
  
  ses_year <- ses_year %>%
    mutate(
      edu9 = audd_level(edu)
    )
  
  ses_year <- ses_year %>%
    mutate(
      edu3 = case_when(
        edu9 %in% c("Early childhood education", "Primary", "Lower secondary") ~ "Low",
        edu9 %in% c("Upper secondary", "Short cycle tertiary") ~ "Medium",
        edu9 %in% c("Bachelor or equivalent", "Master or equivalent", "Doctoral or equivalent") ~ "High"
      )
    )
  
  ## Socio-economic position
  if(year == 2021) {
    ses_year$socio <- NA
  } else {
    akm <- haven::read_sas(paste0(folder_input, "akm", year, ".sas7bdat")) %>%
      distinct()
    colnames(akm) <- tolower(colnames(akm))
    
    if(year >= 1991) {
      akm <- akm %>% select(pnr, socio = socio13)
    } else {
      akm <- akm %>% select(pnr, socio = socio_gl)
    }  
    
    ses_year <- ses_year %>%
      left_join(akm %>% distinct(), by = "pnr")
    
    rm(akm)
  }
  
  
  ## Individual Income
  if(year == 2021) {
    ses_year$inc_ind <- NA
    ses_year$incwage_ind <- NA
    ses_year$incwageself_ind <- NA
    ses_year$incdispon_ind <- NA
    ses_year$public_transfers <- NA
  } else {
    ind <- haven::read_sas(paste0(folder_input, "ind", year, ".sas7bdat")) %>%
      distinct()
    colnames(ind) <- tolower(colnames(ind))
    
    ind <- ind %>% select(pnr, inc_ind = perindkialt_13, incwage_ind = loenmv_13, incwageself_ind = erhvervsindk_13, incdispon_ind = dispon_13, public_transfers = off_overforsel_13)
    
    ses_year <- ses_year %>%
      left_join(ind %>% distinct(), by = "pnr")
    
    rm(ind)
  }
  
  ## Family Income
  if(year == 2021 | year < 1987) {
    ses_year$inc_fam <- NA
    ses_year$incwage_fam <- NA
    ses_year$incdispon_fam <- NA
    ses_year$incdispon_equ <- NA
    ses_year$assets_fam <- NA
    
  } else {
    faik <- haven::read_sas(paste0(folder_input, "faik", year, ".sas7bdat")) %>%
      distinct()
    colnames(faik) <- tolower(colnames(faik))
    
    faik <- faik %>% select(familie_id, inc_fam = famindkomstialt_13, incwage_fam = famloenmv_13, incdispon_fam = famdisponibel_13, incdispon_equ = famaekvivadisp_13, assets_fam = famformrest_ny05)
    
    ses_year <- ses_year %>%
      left_join(faik %>% distinct(), by = "familie_id")
    
    rm(faik)
  }
  
  ### Restrict to our study population
  ses_year <- ses_year %>%
    filter(pnr %in% population$pnr)
  
  ### There are known problems with IND register - take one observation per person
  ses_year <- ses_year %>%
    group_by(pnr) %>%
    mutate(nr_obs = n()) %>%
    slice(1) %>%
    ungroup()
  
   ses_year <- ses_year %>%
     mutate(byear = lubridate::year(birth_d))
  
  ses_year <- ses_year %>%
    mutate(year = !!year) %>%
    select(pnr, year, bef_days, byear, sex, familie_id, nr_obs, civst:assets_fam) %>%
    left_join(inflation)
  
  save(ses_year, file=paste0(folder_output, "ses", year, ".RData"))
  haven::write_dta(ses_year, path=paste0(folder_output, "Stata/ses", year, ".dta"))
  data.table::fwrite(ses_year,file=paste0(folder_output, "csv/ses", year, ".csv"))
  
  ses <- ses %>% bind_rows(ses_year)
  rm(ses_year)
  
}

nrow(ses)
length(unique(ses$pnr))
table(ses$year, ses$nr_obs)

save(ses, file=paste0(folder_output, "ses1985_2021.RData"))
haven::write_dta(ses, path=paste0(folder_output, "Stata/ses1985_2021.dta"))
data.table::fwrite(ses,file=paste0(folder_output, "csv/ses1985_2021.csv"))

